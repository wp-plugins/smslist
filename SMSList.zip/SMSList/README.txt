﻿=== Plugin Name ===
Contributors: gayretsoft
Tags: sms, sms newsletter
Requires at least: 2.8
Tested up to: 2.8 > 3.5.1
Stable tag: 4.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

SMSList

== Description ==

SMSList wordpress eklentisi ile smslist ' inize kayıt olan kişilere sms gönderebilirsiniz.

== Installation ==

1.Eklentiler bölümünden SMSList ekletisini yükleyin.
2.SMSList eklentisi yüklendikten sonra "Eklentiler" menüsünün altındaki "Yüklü Eklentiler" alt menüsüne gidin.
3.SMSList eklantisi bulun ve etkinleştirin.
4.Etkinleştirme işleminden sonra, menü listesinde "SMSList" adında yeni bir menü oluşacaktır.
5."SMSList" menü başlığı altında, "SMSList" alt menüsüne tıklayın. Hakkında bölümünde "Eğer sisteme kayıtlı değil iseniz, kayıt olmak için tıklayınız."
  butonuna tıklayın ve sisteme ücretsiz kayıt olun.
6."SMSList" menü başlığı altında "Ayarlar" alt menüsüne tıklayın, "SMSList Ayarları" sekmesinde gerekli bölgelere oluşturduğunuz hesap bilgilerini
  girerek sisteme kendinizi tanıtın.

Artık "SMSList" menüsü altında "SMS Gönder" alt menüsü yardımıyla sms gönderebilirsiniz.